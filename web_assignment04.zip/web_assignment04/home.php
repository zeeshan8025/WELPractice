<?php
	include("connection.php");
	error_reporting(0);
	session_start();
	if(isset($_SESSION['logged_in'])&& $_SESSION['logged_in']===true)
	{
		header('location:user.php');
		exit;
	}	

?>
<!DOCTYPE html>
<html>
<head>
<title>home page</title>
<link rel="stylesheet" href="styles.css">
</head>
<body>
<nav>
	<div class="main">
		<div class="logo">
			<img src="logo.png" alt="logo">
		</div>
	</div>
</nav>
<div class="login">
	<div class="login_header">
		<h3> User Login</h3>
	</div>
	<div class="login_body">
		<form method="post" >
			<label for="user_email"><b>User Email :</b></label>
			<input type="text" name="u_email"><br><br>
			<label for="user_password"><b>User Password :</b></label>
			<input type="password" name="u_password"><br><br>
			<input type="submit" name="login" value="Log In"><br>
		</form>
	</div>
</div>
<?php
	if(isset($_POST['login'])){
		$u_email = $_POST['u_email'];
		$u_password = $_POST['u_password'];
		$_SESSION['login_user']= $_POST['u_email'];
		$query1 = "SELECT * FROM USER WHERE email='$u_email' && password='$u_password'";
		$data1 = mysqli_query($conn , $query1);
		$total = mysqli_num_rows($data1);
		$result = mysqli_fetch_assoc($data1);
		
		$query_1 = "SELECT * FROM USER WHERE email='$u_email' && password!='$u_password'";
		$data_1 = mysqli_query($conn , $query_1);
		$total_1 = mysqli_num_rows($data_1);

		if( $u_email!="" && $u_password!="" ){	
			if($total == 1){
				$_SESSION['user_name'] = $result['name'];
				$_SESSION['user_email'] = $result['email'];
				$_SESSION['user_image'] = $result['image'];
				$_SESSION['sender_id'] = $result['id'];
				$_SESSION['logged_in'] = true;
				echo "sender id is ".$_SESSION['sender_id'];
				header("location:user.php");
				
			}
			else{
				if($total_1 == 1){
					echo "<h4 style='color:red;'><center>password is incorrect</center></h4>";
				}
				else{
					echo "<h4 style='color:red;'><center>Acound doesnot exist</center></h4>";
				}
			}	
		}
		else{
			echo "<h4 style='color:red;'><center>All fields required</center></h4>";
		}
	}
?>
	
<div class="login">
	<div class="login_header">
		<h3> User Registration</h3>
	</div>
	<div class="login_body">
		<form method="POST"  enctype="multipart/form-data" >
			<label for="user_name"><b>Your Full Name :</b></label>
			<input type="text" name="user_name"><br><br>
			<label for="user_email"><b>Your Email : </label>
			<input type="email" name="user_email"><br><br>
			<label for="user_password"><b>Your Password  :</b></label>
			<input type="password" name="user_password"><br><br>
			<label for="user_picture"><b>Your Picture :</label>
			<input type="file" name="user_picture" class="file"><br><br>
			<input type="submit" name="sign_up" value="Register"><br>
		</form>
	</div>
</div>
<?php
	if($_POST['sign_up']){
		$u_name = $_POST['user_name'];
		$u_email = $_POST['user_email'];
		$u_password = $_POST['user_password'];
		$id;
		
		$filename = $_FILES["user_picture"]["name"];
		$tempname = $_FILES["user_picture"]["tmp_name"];
		$folder = "directory/".$filename;
		move_uploaded_file($tempname ,$folder);
		
		$query1 = "SELECT * FROM USER WHERE email='$u_email'";
		$data1 = mysqli_query($conn , $query1);
		$total = mysqli_num_rows($data1);
		
		if($total == 0 ){
			if($u_name!="" && $u_email!="" && $u_password!="" && $filename!=""){
				$query = "INSERT INTO USER (id , name , email , password , image ) 
				VALUES ( NULL , '$u_name' , '$u_email' , '$u_password' , '$folder')";
				$data = mysqli_query($conn , $query);
				
					if($data){
						echo "<h4 style='color:red;'><center>Acount created successfully</center><br></h4>";
					}
					else
						echo "<h4 style='color:red;'><center>data not inserted</center><br></h4>";
			}
			else
				echo "<h4 style='color:red;'><center>All fields are required</center><br></h4>";
		}
		else
			echo "<h4 style='color:red;'><center>email already exist</center><br></h4>";
	}	
?>
<div class="footer">
<center>
@ all rights reserved
</center>
</div>

</body>
</html>

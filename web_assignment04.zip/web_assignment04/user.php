<?php
	include("connection.php");
	error_reporting(0);
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
<title>User Page</title>
<link rel="stylesheet" href="styles.css">
</head>
<body>
<nav>
	<div class="main">
		<div class="logo">
			<img src="logo.png" alt="logo">
		</div>
	</div>
</nav>
<div class="user_info" >
	<div class="user_header">
	<img src="<?php echo $_SESSION['user_image'];  ?>">
	</div>
	<div class="user_info">
	<p style="padding:15px;"><?php echo	$_SESSION['user_name']."<br>".$_SESSION['user_email'];  ?></p>
	</div>
</div>

<div class="user_actions">
	<a href="send_message.php">Send Message</a><br>
	<a href="inbox.php">Inbox</a><br>
	<a href="outbox.php">Outbox</a><br>
	<a href="sign_out.php">SignOut</a><br>
</div>
<div class="footer" style="margin-top:15px;">
	<center>
	@ all rights reserved
	</center>
</div>
</body>
</html>

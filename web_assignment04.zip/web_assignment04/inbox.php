<?php
	include("connection.php");
	error_reporting(0);
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
<title>User Page</title>
<link rel="stylesheet" href="styles.css">
</head>
<body>
<nav>
	<div class="main">
		<div class="logo">
			<img src="logo.png" alt="logo">
		</div>
	</div>
</nav>
<div class="outer_template">
	<div class="user_action">
		<a href="send_message.php">Send Message</a><br>
		<a href="inbox.php">Inbox</a><br>
		<a href="outbox.php">Outbox</a><br>
		<a href="sign_out.php">SignOut</a><br>
	</div>
	<div class="outbox_message">
		<div class="login_header">
			<h3> Inbox Message</h3>
		</div>
		<div class="message_body">
		<?php
			$m_email=$_SESSION['user_email'];
			$query = "SELECT * FROM MESSAGE WHERE m_email='$m_email'";
			$data = mysqli_query($conn , $query);
			$total = mysqli_num_rows($data);	
			if($total !=0){
				while($result = mysqli_fetch_assoc($data))
				{
					$sender_id = $result[sender_id];
					$query1 = "SELECT * FROM USER WHERE id='$sender_id'";
					$data1 = mysqli_query($conn , $query1);
					$total1 = mysqli_num_rows($data1);	
					if($total1 !=0){
						while($result1 = mysqli_fetch_assoc($data1))
						{
							echo "Sender email <b>".$result1[email]."</b>";
						}
					}
					echo "<br>".$result[m_msg]."<br><br>";
				}
			}
			else{
				echo "Inbox is empty";
			}
		?>
		</div>
	</div>
	
</div>


</body>
</html>

<?php
	include("connection.php");
	error_reporting(0);
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
<title>User Page</title>
<link rel="stylesheet" href="styles.css">
</head>
<body>
<nav>
	<div class="main">
		<div class="logo">
			<img src="logo.png" alt="logo">
		</div>
	</div>
</nav>

<div class="outer_template">
	<div class="user_action" >
		<a href="send_message.php">Send Message</a><br>
		<a href="inbox.php">Inbox</a><br>
		<a href="outbox.php">Outbox</a><br>
		<a href="sign_out.php">SignOut</a><br>
	</div>
	<div class="outbox_message" >
		<div class="login_header">
			<h3>Outbox </h3>
		</div>
		<div class="message_body">
		
		<?php
			$user_id = $_SESSION['sender_id'];
			if($user_id!=0){
			$query = "SELECT * FROM message WHERE sender_id='$user_id'";
			$data = mysqli_query($conn , $query);
			$total = mysqli_num_rows($data);
			
				if($total !=0){
					while($result = mysqli_fetch_assoc($data))
					{
						echo "Message send to <b>".$result[m_email]."</b>";
						echo "<br>".$result[m_msg]."<br><br>";
					}
				}
				else{
					echo "outbox is empty";
				}
			}
			else{
				echo "failed";
			}
		?>
		</div>
	</div>
	
</div>

</body>
</html>

<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "webproject";
	
	$conn = mysqli_connect($servername , $username ,$password ,$dbname );
	
	if($conn)
	{
		//echo "connection ok"."<br>";
	}
	else
	{
		die("connection failed due to ".mysqli_connect_error());
	}

?>
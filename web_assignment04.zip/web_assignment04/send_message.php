<?php
	include("connection.php");
	error_reporting(0);

?>
<?php

	if($_POST['submit']){
		session_start();
		$m_email = $_POST['reciver_email'];
		$m_message = $_POST['message'];
		$s_id = $_SESSION['sender_id'];
	
		$query = "SELECT * FROM USER WHERE email='$m_email'";
		$data = mysqli_query($conn , $query);
		$total = mysqli_num_rows($data);	
		
		if($m_email!="" && $m_message!="" ){
			if($total == 1){
				$query1 = "INSERT INTO MESSAGE (m_id , m_email ,m_msg , sender_id ) 
					VALUES ( NULL , '$m_email' , '$m_message' , $s_id )";
				$data1 = mysqli_query($conn , $query1);
				if($data1){
					echo "<br>Email send successfully";
					header("location:user.php");
				}
				else
					echo "<br>"."Email sending failed";

			}
			else{
				echo "reciver email address doesnot exit";
			}
		}
		else{
			echo "all fields required<br>";
		}
			
	}		
		
?>
<!DOCTYPE html>
<html>
<head>
<title>Message Page</title>
<link rel="stylesheet" href="styles.css">
</head>
<body>
<nav>
	<div class="main">
		<div class="logo">
			<img src="logo.png" alt="logo">
		</div>
	</div>
</nav>

<div class="outer_template">
	<div class="user_action">
		<a href="send_message.php">Send Message</a><br>
		<a href="inbox.php">Inbox</a><br>
		<a href="outbox.php">Outbox</a><br>
		<a href="sign_out.php">SignOut</a><br>
	</div>
	<div class="send_message">
		<div class="login_header">
			<h3> Send Message</h3>
		</div>
		<div class="message_body">
			<form method="post">
				<label for="reciver_email"><b>Reciver Email :</b></label>
				<input type="email" name="reciver_email"><br><br>
				<label for="message"><b>Your Message :</b></label>
				<input type="text" name="message"><br><br>		
		
				<input type="submit" name="submit" value="Send Message"><br>
			</form>
		</div>
	</div>
	
</div>

<div class="footer" style="margin-top:30px;">
	<center>
	@ all rights reserved
	</center>
</div>


</body>
</html>
